NEARUSDT Telegram Alerts — папка для GitHub

Что делает:
- Проверяет закрытые 15-минутные свечи каждые 5 минут.
- Сначала использует Bybit linear API.
- Если Bybit блокирует запрос с GitHub Actions, пробует Binance Futures как резервный источник.
- Отправляет Telegram только при LONG/SHORT по простым условиям EMA20/EMA50, RSI и пробою диапазона.
- Не открывает сделки и не гарантирует прибыль.

Установка:
1. В репозитории baybit-terminal открой Add file → Upload files.
2. Загрузи папку .github/workflows/near-alerts.yml (GitHub должен сохранить путь .github/workflows/near-alerts.yml).
   Если мобильный интерфейс не позволяет загрузить скрытую папку, открой существующий файл:
   .github/workflows/near-alerts.yml и замени его содержимое кодом из этого файла.
3. В Settings → Secrets and variables → Actions должны быть secrets:
   BOT_TOKEN — новый токен Telegram-бота;
   CHAT_ID — твой chat ID.
4. Открой Actions → NEARUSDT Telegram Alerts → Run workflow.

ВАЖНО:
- Токен, который ранее отправлялся в переписке, считай раскрытым: отзови его через @BotFather (/revoke), создай новый и обнови secret BOT_TOKEN. Не вставляй токен в YAML или публичные файлы.
- Если сигнал рассчитан по Binance Futures, в сообщении будет явно указан резервный источник. Цена/сигнал могут немного отличаться от Bybit.
- Расписание GitHub Actions не гарантирует запуск ровно каждые 5 минут.
